Hi, so here's what to do. Go download the nanoKONTROL2 editor software from Korg's website, then load the cobalt.nktrl2_data file using that software.

Then, install pd (puredata.info). You'll want Pd-extended. Pd is not for the faint-of-heart. Run this patch. You'll probably have to muck about and set it up so that pd sees the Korg device as the MIDI input.

In the patch, you always want to disconnect first, before connecting.

Once it's working and you've put in all of the right IP addresses and ports and whatnot, you should have the Korg sliders moving Eos subs.

Good luck!
Luke
luke.delwiche@etcconnect.com
